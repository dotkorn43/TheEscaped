package pacman.recursos;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

public class Lector {

    public static String lector = "";
    public static String aux = "";
    public static String pun = "";
    public static int nj = 1;

    public static void score(int score, String nombre) throws Exception {
        File f2 = new File("score.txt");
        FileWriter fw = new FileWriter(f2, true);
        BufferedWriter bw = new BufferedWriter(fw);
        Calendar fecha = new GregorianCalendar();
        int year = fecha.get(Calendar.YEAR);
        int month = fecha.get(Calendar.MONTH);
        int day = fecha.get(Calendar.DAY_OF_MONTH);
        int time = fecha.get(Calendar.HOUR_OF_DAY);
        int minute = fecha.get(Calendar.MINUTE);
        pun = nombre + ":  " + score + "\n วัน เดือน ปี: " + day + "/" + (month + 1) + "/" + year + "\n เวลา " + time + ":" + minute + "\n \n";
        bw.write(pun);
        bw.close();
        nj++;

    }

    public static void hscore() throws Exception {
        File f = new File("score.txt");
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        while (true) {
            aux = br.readLine();
            if (aux != null) {
                lector = lector + aux + "\n";
            } else {
                break;
            }
        }
        br.close();
        fr.close();
        //bw.close();
        JOptionPane.showMessageDialog(null, lector);
        lector = "";
    }

}
